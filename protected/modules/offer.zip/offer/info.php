<?php
return array(
    'name'=>'offer',
    'title'=>'offer',
    'description'=>'Offer Module',
    'version'=>'0.0.1',
    'author'=>array(
        'url'=>'http://webwest.com.ua',
        'name'=>'Igor Tulashvili',
        'email'=>'tulik.igor@gmail.com',
    ),
    'admin_controller'=>'/admin/offer/index',
);